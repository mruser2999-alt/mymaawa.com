MyMaawa - photos
================
Every photo is a .webp file. To replace one, either save your photo as .webp
with the same name, or delete the .webp and upload a .jpg with the same name
(the app falls back to .jpg automatically).

Sizes: home garden photos hero_<season>_<time> 1600 x 900;
all other photos at least 1280 x 720, wide 16:9. Keep each file under 300 KB.
Use only photos you have the right to use. Do NOT use images that show prophets.
